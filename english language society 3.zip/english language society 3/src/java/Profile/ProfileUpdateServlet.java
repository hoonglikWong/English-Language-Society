/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Profile;

import Model.Person;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
@MultipartConfig
public class ProfileUpdateServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String IC = req.getParameter("IC");
        String regDate = req.getParameter("RegDate");
        String Status = req.getParameter("Status");
        String Position = req.getParameter("Position");
        String Name = req.getParameter("Name");
        String Email = req.getParameter("Email");
        String phoneNum = req.getParameter("phoneNum");
        String Gender = req.getParameter("Gender");
        String newPassword = req.getParameter("PASSWORD");
        String Psw = req.getParameter("Psw");
        Person p;
        Person p2;


        String fileName;
        try {
            Part filePart = req.getPart("file"); // Retrieves <input type="file" name="file">
           fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.

            InputStream fileContent = filePart.getInputStream();
            String prefix = getServletContext().getRealPath("/") + "image";
            prefix = prefix.replace("\\build", "");
            File path = new File(prefix);
            File file = new File(path, fileName);
            Files.copy(fileContent, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (DirectoryNotEmptyException ex) {
            fileName = req.getParameter("CurrentImage");
        }

        if (newPassword.equals("")) {
            p2 = new Person(IC, Name, phoneNum, Psw, Status, regDate, Gender, Email, Position, fileName);
        } else {
            p2 = new Person(IC, Name, phoneNum, newPassword, Status, regDate, Gender, Email, Position, fileName);
        }

        HttpSession session = req.getSession();
        session.setAttribute("personlogin", p2);
        try {
            utx.begin();
            em.merge(p2);
            utx.commit();
            resp.sendRedirect("ProfilePage.jsp");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
