/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Controller.ManageParticipation;

import Model.Participation;
import Model.Payment;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.annotation.Resource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class ParticipationPaidServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String participationid = req.getParameter("participationid");
        String excoid = req.getParameter("excoid");

        Participation p1 = em.find(Participation.class, participationid);
        p1.setStatus("PAID");
        
        String status = "PAID";

        Query q = em.createNamedQuery("Payment.findAll");
        List<Payment> PaymentList = q.getResultList();

        String currentID = PaymentList.get(PaymentList.size() - 1).getPaymentid();
        int numIndex = Integer.parseInt(currentID.substring(2));
        numIndex = numIndex + 1;
        String PaymentNewID = "PA" + numIndex;

        Query q2 = em.createNamedQuery("Person.findAll");
        List<Person> PersonList = q2.getResultList();

        String payeeic = p1.getIc().getIc();

        boolean valid = false;
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(payeeic)) {
                valid = true;
            }
        }

        String amount = "";
        if (valid) {
            amount = p1.getEventid().getMemberprice();
        } else {
            amount = p1.getEventid().getNonmemberprice();
        }
        
        
        
       

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String today = formatter.format(date);

        Person payeeclass = new Person(payeeic);
        Person recipientclass = new Person(excoid);
        
        sendMail(participationid,payeeic,status);

        Payment paymentdetail = new Payment(PaymentNewID, participationid, amount, today, recipientclass, payeeclass);

        try {
            utx.begin();
            em.merge(p1);
            em.persist(paymentdetail);
            utx.commit();
            resp.sendRedirect("RetrieveParticipation");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

    public void sendMail(String participationid,String payeeic,String status) {

        Query q = em.createNamedQuery("Participation.findAll");
        List<Participation> ParticipationList = q.getResultList();

        Participation parti = new Participation();
        for (int i = 0; i < ParticipationList.size(); i++) {
            if (ParticipationList.get(i).getParticipationid().equals(participationid)) {
                parti = ParticipationList.get(i);
            }
        }
        
        Query q2 = em.createNamedQuery("Person.findAll");
        List<Person> PersonList = q2.getResultList();

        boolean valid = false;
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(payeeic)) {
                valid = true;
            }
        }
        Date date = Calendar.getInstance().getTime();

        String amount = "";
        if (valid) {
            amount = parti.getEventid().getMemberprice();
        } else {
            amount = parti.getEventid().getNonmemberprice();
        }

        final String username = "hotlinkwong@gmail.com";
        final String password = "Lik96309630";

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("hotlinkwong@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(parti.getIc().getEmail()));
            
            message.setSubject("Application");
            message.setContent("<!doctype html>\n"
                    + "<html>\n"
                    + "<head>\n"
                    + "    <meta charset=\"utf-8\">\n"
                    + "    <title>A simple, clean, and responsive HTML invoice template</title>\n"
                    + "    \n"
                    + "    <style>\n"
                    + "    .invoice-box {\n"
                    + "        max-width: 800px;\n"
                    + "        margin: auto;\n"
                    + "        padding: 30px;\n"
                    + "        border: 1px solid #eee;\n"
                    + "        box-shadow: 0 0 10px rgba(0, 0, 0, .15);\n"
                    + "        font-size: 16px;\n"
                    + "        line-height: 24px;\n"
                    + "        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;\n"
                    + "        color: #555;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table {\n"
                    + "        width: 100%;\n"
                    + "        line-height: inherit;\n"
                    + "        text-align: left;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table td {\n"
                    + "        padding: 5px;\n"
                    + "        vertical-align: top;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr td:nth-child(2) {\n"
                    + "        text-align: right;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.top table td {\n"
                    + "        padding-bottom: 20px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.top table td.title {\n"
                    + "        font-size: 45px;\n"
                    + "        line-height: 45px;\n"
                    + "        color: #333;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.information table td {\n"
                    + "        padding-bottom: 40px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.heading td {\n"
                    + "        background: #eee;\n"
                    + "        border-bottom: 1px solid #ddd;\n"
                    + "        font-weight: bold;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.details td {\n"
                    + "        padding-bottom: 20px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.item td{\n"
                    + "        border-bottom: 1px solid #eee;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.item.last td {\n"
                    + "        border-bottom: none;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.total td:nth-child(2) {\n"
                    + "        border-top: 2px solid #eee;\n"
                    + "        font-weight: bold;\n"
                    + "    }\n"
                    + "    \n"
                    + "    @media only screen and (max-width: 600px) {\n"
                    + "        .invoice-box table tr.top table td {\n"
                    + "            width: 100%;\n"
                    + "            display: block;\n"
                    + "            text-align: center;\n"
                    + "        }\n"
                    + "        \n"
                    + "        .invoice-box table tr.information table td {\n"
                    + "            width: 100%;\n"
                    + "            display: block;\n"
                    + "            text-align: center;\n"
                    + "        }\n"
                    + "    }\n"
                    + "    \n"
                    + "    /** RTL **/\n"
                    + "    .rtl {\n"
                    + "        direction: rtl;\n"
                    + "        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .rtl table {\n"
                    + "        text-align: right;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .rtl table tr td:nth-child(2) {\n"
                    + "        text-align: left;\n"
                    + "    }\n"
                    + "    </style>\n"
                    + "</head>\n"
                    + "\n"
                    + "<body>\n"
                    + "    <div class=\"invoice-box\">\n"
                    + "        <table cellpadding=\"0\" cellspacing=\"0\">\n"
                    + "            <tr class=\"top\">\n"
                    + "                <td colspan=\"2\">\n"
                    + "                    <table>\n"
                    + "                        <tr>\n"
                    + "                            <td class=\"title\">\n"
                    + "                                <img src=\"https://i.imgur.com/PV5oSRZ.png\" style=\"max-width: 300px;width: 100%\"/>\n"
                    + "                            </td>\n"
                    + "                            \n"
                    + "                            <td>\n"
                    + "                                Registration Number#: " + parti.getParticipationid() + "<br>\n"
                    + "                                Created: " + date + "<br>\n"
                    + "                            </td>\n"
                    + "                        </tr>\n"
                    + "                    </table>\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"information\">\n"
                    + "                <td colspan=\"2\">\n"
                    + "                    <table>\n"
                    + "                        <tr>\n"
                    + "                            <td>\n"
                    + "                                English Language Society<br>\n"
                    + "                                Kampus Utama, Jalan Genting Kelang,<br>\n"
                    + "                                53300 Kuala Lumpur\n"
                    + "                            </td>\n"
                    + "                            \n"
                    + "                            <td>\n"
                    + "                                <br>\n"
                    + "                               " + parti.getIc().getPersonname() + "<br>\n"
                    + "                               " + parti.getIc().getEmail() + "<br>\n"
                    + "                            </td>\n"
                    + "                        </tr>\n"
                    + "                    </table>\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"heading\">\n"
                    + "                <td>\n"
                    + "                    Status\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"details\">\n"
                    + "                <td>\n"
                    + "                    " + status + "\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"heading\">\n"
                    + "                <td>\n"
                    + "                    Event Registration\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    Price\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item\">\n"
                    + "                <td>\n"
                    + "                    " + parti.getEventid().getEventname() + "\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                   " + amount + "\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item\">\n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item last\">\n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"total\">\n"
                    + "                <td></td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                   Total:RM " + amount + "\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "        </table>\n"
                    + "    </div>\n"
                    + "</body>\n"
                    + "</html>\n"
                    + "\n", "text/html");

            Transport.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }

}
