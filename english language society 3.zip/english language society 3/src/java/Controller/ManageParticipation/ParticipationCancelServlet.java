/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Controller.ManageParticipation;

import Model.Participation;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.Query;

/**
 *
 * @author hoonglik
 */
public class ParticipationCancelServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String participationid = req.getParameter("participationid");
        Participation p1 = em.find(Participation.class, participationid);
        p1.setStatus("CANCELLED");
        sendMail(participationid);
        try {
            utx.begin();
            em.merge(p1);
            utx.commit();
            resp.sendRedirect("RetrieveParticipation");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }

    public void sendMail(String participationid) {

        Query q = em.createNamedQuery("Participation.findAll");
        List<Participation> ParticipationList = q.getResultList();

        Participation parti = new Participation();
        for (int i = 0; i < ParticipationList.size(); i++) {
            if (ParticipationList.get(i).getParticipationid().equals(participationid)) {
                parti = ParticipationList.get(i);
            }
        }

        final String username = "hotlinkwong@gmail.com";
        final String password = "Lik96309630";

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("hotlinkwong@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(parti.getIc().getEmail()));

            message.setSubject("Event Registration Cancelled");
            message.setText("Hi," + parti.getIc().getPersonname() 
                    + ",\nYour Event Registration ("+ parti.getParticipationid() +") Has Been Cancelled!");

            Transport.send(message);
            
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }
}
