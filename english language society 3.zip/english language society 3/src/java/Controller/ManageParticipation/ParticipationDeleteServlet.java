/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Controller.ManageParticipation;

import Model.Participation;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class ParticipationDeleteServlet extends HttpServlet {

   @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String participationid = req.getParameter("participationid");
        Participation p1 = em.find(Participation.class, participationid);
        
        try {
            utx.begin();
            em.remove(em.merge(p1));
            utx.commit();
            resp.sendRedirect("RetrieveParticipation");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }
    
    
    

}
