/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Controller.ManageParticipation;

import Model.Event;
import Model.Participation;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class ParticipationEditServlet extends HttpServlet {
    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String participationID = req.getParameter("participationID");
        String ID = req.getParameter("ID");
        String eventselect = req.getParameter("eventselect");
        String status = req.getParameter("status");

        Person person = new Person(ID);
        Event event = new Event(eventselect);

        Participation p1 = new Participation(participationID, status, event, person);

        try {
            utx.begin();
            em.merge(p1);
            utx.commit();
            resp.sendRedirect("RetrieveParticipation");
            //resp.sendRedirect("MainPage.jsp");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }

}
