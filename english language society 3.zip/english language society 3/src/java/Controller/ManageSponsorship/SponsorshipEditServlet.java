/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.ManageSponsorship;

import Model.Event;
import Model.Item;
import Model.Sponsor;
import Model.Sponsorship;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Wong Guo Zheng
 */
public class SponsorshipEditServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sponsorshipID = req.getParameter("sponsorshipID");
        String sponsorselect = req.getParameter("sponsorselect");
        String eventselect = req.getParameter("eventselect");
        String itemselect = req.getParameter("itemselect");
        String quantity = req.getParameter("quantity");
        String dateselect = req.getParameter("dateselect");

         Sponsor spon = new Sponsor(sponsorselect);
        Event event;
        if(eventselect.equals("")){
            event = null;
        }
        else{
            event = new Event(eventselect);
        }
        Item item = new Item(itemselect);

        Sponsorship sponsorshipdetail = new Sponsorship(sponsorshipID, quantity, dateselect, event, item, spon);

        try {
            utx.begin();
            em.merge(sponsorshipdetail);
            utx.commit();

            resp.sendRedirect("RetrieveSponsorship");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
