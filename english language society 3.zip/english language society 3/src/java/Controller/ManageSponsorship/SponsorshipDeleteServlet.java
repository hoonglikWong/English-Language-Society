/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.ManageSponsorship;

import Model.Sponsor;
import Model.Sponsorship;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

/**
 *
 * @author Wong Guo Zheng
 */
public class SponsorshipDeleteServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//        Query q = em.createNamedQuery("Sponsorship.findAll");
//        List<Sponsorship> SponsorshipList = q.getResultList();
//        String sponsorshipid = req.getParameter("sponsorshipid");
//        int indexsponsorshipid = Integer.parseInt(sponsorshipid);
//        Sponsorship SponsorshipDetail = SponsorshipList.get(indexsponsorshipid);

        String sponsorshipid = req.getParameter("sponsorshipid");
        Sponsorship sponsorDel = em.find(Sponsorship.class, sponsorshipid);

        try {
            utx.begin();
            em.remove(em.merge(sponsorDel));
            utx.commit();
            HttpSession session = req.getSession();
            resp.sendRedirect("RetrieveSponsorship");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }

}
