/**
 *
 * @author Wong Hoong Lik
 */
/**
 *
 * @author Lee Meng Jian
 */


package Controller;

import Model.Event;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

public class firstPageServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Person personlogin = new Person();

        Query q2 = em.createNamedQuery("Event.findAll");
        List<Event> EventList = q2.getResultList();
        
        HttpSession session = req.getSession();
        session.setAttribute("personlogin", personlogin);
        session.setAttribute("EventList", EventList);
        resp.sendRedirect("mainPage.jsp");
    }

}
