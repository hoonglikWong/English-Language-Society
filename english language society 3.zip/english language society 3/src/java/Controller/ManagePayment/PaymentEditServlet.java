/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */

package Controller.ManagePayment;

import Model.Payment;
import Model.Person;
import Model.Sponsor;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class PaymentEditServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String ID = req.getParameter("ID");
        String purpose = req.getParameter("purpose");
        String amount = req.getParameter("amount");
        String date = req.getParameter("date");
        String Payee = req.getParameter("Payee");
        String recipient = req.getParameter("recipient");
        
        Person payeeobject = new Person(Payee);
        Person recipientobject = new Person(recipient);
        
        Payment paymentdetail = new Payment(ID,purpose,amount,date,recipientobject,payeeobject); 
        
        try {
            utx.begin();
            em.merge(paymentdetail);
            utx.commit();
            resp.sendRedirect("RetrievePayment");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
