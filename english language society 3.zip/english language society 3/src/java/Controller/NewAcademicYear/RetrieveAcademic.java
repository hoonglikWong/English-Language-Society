/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.NewAcademicYear;

import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.GregorianCalendar;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

/**
 *
 * @author Lee Meng Jian
 */
public class RetrieveAcademic extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        GregorianCalendar today = new GregorianCalendar();

        int month = today.get(GregorianCalendar.MONTH);

        if (month == 0) {
            Query q3 = em.createNamedQuery("Person.findAll");
            List<Person> PersonList = q3.getResultList();

            HttpSession session = req.getSession();
            session.setAttribute("PersonList", PersonList);
            resp.sendRedirect("NewAcademicYear.jsp");

        } else {
            PrintWriter out = resp.getWriter();

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title></title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<form action=\"mainPage.jsp\"><input type=\"submit\" id=\"submit\" style=\"display=none\"></form><script>window.onload = function() {alert(\"Creation of new terms of office can only be done in January!\");document.getElementById(\"submit\").click();}</script>");
            out.println("</body>");
            out.println("</html>");

        }

    }
}
