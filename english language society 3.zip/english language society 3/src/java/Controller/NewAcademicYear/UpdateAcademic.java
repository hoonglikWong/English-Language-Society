/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.NewAcademicYear;

import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Lee Meng Jian
 */
public class UpdateAcademic extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String presidentIc = req.getParameter("presidentIc");
        String vicePresidentIc = req.getParameter("vicePresidentIc");
        String treasurerIc = req.getParameter("treasurerIc");
        String secretaryIc = req.getParameter("secretaryIc");

        Query q3 = em.createNamedQuery("Person.findAll");
        List<Person> PersonList = q3.getResultList();

        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getExcoposition().equals("PRESIDENT")) {
                PersonList.get(i).setStatus("MEMBER");
                PersonList.get(i).setExcoposition("");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getExcoposition().equals("VICE PRESIDENT")) {
                PersonList.get(i).setStatus("MEMBER");
                PersonList.get(i).setExcoposition("");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getExcoposition().equals("TREASURER")) {
                PersonList.get(i).setStatus("MEMBER");
                PersonList.get(i).setExcoposition("");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getExcoposition().equals("SECRETARY")) {
                PersonList.get(i).setStatus("MEMBER");
                PersonList.get(i).setExcoposition("");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            }
        }
        
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(presidentIc)) {
                PersonList.get(i).setStatus("EXCO");
                PersonList.get(i).setExcoposition("PRESIDENT");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getIc().equals(vicePresidentIc)) {
                PersonList.get(i).setStatus("EXCO");
                PersonList.get(i).setExcoposition("VICE PRESIDENT");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getIc().equals(treasurerIc)) {
                PersonList.get(i).setStatus("EXCO");
                PersonList.get(i).setExcoposition("TREASURER");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            } else if (PersonList.get(i).getIc().equals(secretaryIc)) {
                PersonList.get(i).setStatus("EXCO");
                PersonList.get(i).setExcoposition("SECRETARY");
                try {
                    utx.begin();
                    em.merge(PersonList.get(i));
                    utx.commit();
                } catch (Exception ex) {
                    resp.sendRedirect("ErrorPage.jsp");
                }
            }
        }
        resp.sendRedirect("firstPageServlet");
    }

}
