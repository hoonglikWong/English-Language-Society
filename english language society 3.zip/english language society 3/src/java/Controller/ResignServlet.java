/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wong Hoong Lik
 */


package Controller;

import Model.Payment;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class ResignServlet extends HttpServlet {
    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String IC = req.getParameter("personID");
        Person person = em.find(Person.class, IC);
        person.setStatus("RESIGNED");
        person.setExcoposition("");

        try {
            utx.begin();
            em.merge(person);
            utx.commit();
            resp.sendRedirect("firstPageServlet");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
