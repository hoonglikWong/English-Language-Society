/**
 *
 * @author Lee Meng Jian
 */


package Controller;

import Model.Event;
import Model.Participation;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

public class EventRegistrationConfirmationServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String regIC = req.getParameter("IC");
        String Name = req.getParameter("Name");
        String phoneNum = req.getParameter("phoneNum");
        String Email = req.getParameter("Email");
        String Gender = req.getParameter("Gender");
        String regEventID = req.getParameter("eventID");
        PrintWriter out = resp.getWriter();
        String regStatus = "PENDING";
        boolean matched = false;
        boolean joined = false;

        try {

            Query q2 = em.createNamedQuery("Participation.findAll");
            List<Participation> PartiList = q2.getResultList();

            Query q = em.createNamedQuery("Person.findAll");
            List<Person> PersonList = q.getResultList();

            Query q3 = em.createNamedQuery("Event.findAll");
            List<Event> EventList = q3.getResultList();

            String currentID = PartiList.get(PartiList.size() - 1).getParticipationid();
            int numIndex = Integer.parseInt(currentID.substring(2));
            numIndex = numIndex + 1;
            String PartID = "PI" + numIndex;

            Date date = Calendar.getInstance().getTime();
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String today = formatter.format(date);

            for (int i = 0; i < PartiList.size(); i++) {
                if (PartiList.get(i).getIc().getIc().equals(regIC)) {
                    if (PartiList.get(i).getEventid().getEventid().equals(regEventID)) {
                        joined = true;
                    }
                }
            }
            if (joined) {

                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title></title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<form action=\"EventRegistration.jsp\"><input type=\"submit\" id=\"submit\" style=\"display=none\"></form><script>window.onload = function() {alert(\"You have already joined this event!\");document.getElementById(\"submit\").click();}</script>");
                out.println("</body>");
                out.println("</html>");
            } else {
                int eventIdIndex = 0;
                for (int i = 0; i < EventList.size(); i++) {
                    if (EventList.get(i).getEventid().equals(regEventID)) {
                        eventIdIndex = i;
                    }
                }
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                Date date1 = format.parse(EventList.get(eventIdIndex).getStartregdate());
                Date date2 = format.parse(today);
                Date date3 = format.parse(EventList.get(eventIdIndex).getEndregdate());

                if ((date1.compareTo(date2) > 0) || (date2.compareTo(date3) > 0)) {
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title></title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<form action=\"EventRegistration.jsp\"><input type=\"submit\" id=\"submit\" style=\"display=none\"></form><script>window.onload = function() {alert(\"You can only join during the registraion period!\");document.getElementById(\"submit\").click();}</script>");
                    out.println("</body>");
                    out.println("</html>");
                } else {

                    for (int i = 0; i < PersonList.size(); i++) {
                        if (PersonList.get(i).getIc().equals(regIC)) {
                            matched = true;
                        }
                    }

                    if (!matched) {

                        Person person = new Person(regIC, Name, phoneNum, "", "OUTSIDER", today, Gender, Email, "","");

                        utx.begin();
                        em.persist(person);
                        utx.commit();
                    }

                    Person personid = new Person(regIC);
                    Event eventid = new Event(regEventID);
                    Participation parti = new Participation(PartID, regStatus, eventid, personid);
                    utx.begin();
                    em.persist(parti);
                    utx.commit();

                    HttpSession session = req.getSession();
                    session.setAttribute("lastConfirmReg", parti);

                    resp.sendRedirect("LastEventConfirmation.jsp");
                }
            }
        } catch (Exception ex) {
            out.println(ex.getMessage());
        }

    }

}
