/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Lee Meng Jian
 */

package Controller.ManageEvent;

import Model.Event;
import Model.Item;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class EventEditServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String eventID = req.getParameter("eventID");
//        Event eventUp = em.find(Event.class,eventID);
        String eventName = req.getParameter("eventName");
        String MemPrice = req.getParameter("MemPrice");
        String NonMemPrice = req.getParameter("NonMemPrice");
        String eventdesc = req.getParameter("eventdesc");
        String EventCat = req.getParameter("EventCat");
        String StartRegDate = req.getParameter("StartRegDate");
        String EndRegDate = req.getParameter("EndRegDate");
        String StartDate = req.getParameter("StartDate");
        String EndDate = req.getParameter("EndDate");
        String Picture = req.getParameter("Picture");

        Event eventdetail = new Event(eventID, eventName, eventdesc, EventCat, StartRegDate, EndRegDate, StartDate, EndDate, MemPrice, NonMemPrice,Picture);
        try {
            utx.begin();
            em.merge(eventdetail);
            utx.commit();
            
            resp.sendRedirect("RetrieveEvent");
            //resp.sendRedirect("MainPage.jsp");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
