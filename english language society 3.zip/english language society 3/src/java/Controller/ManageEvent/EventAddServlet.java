/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Lee Meng Jian
 */

package Controller.ManageEvent;

import Model.Event;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
@MultipartConfig
public class EventAddServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String eventID = req.getParameter("eventID");
        String eventName = req.getParameter("eventName");
        String MemPrice = req.getParameter("MemPrice");
        String NonMemPrice = req.getParameter("NonMemPrice");
        String eventdesc = req.getParameter("eventdesc");
        String EventCat = req.getParameter("EventCat");
        String StartRegDate = req.getParameter("StartRegDate");
        String EndRegDate = req.getParameter("EndRegDate");
        String StartDate = req.getParameter("StartDate");
        String EndDate = req.getParameter("EndDate");

        Part filePart = req.getPart("file"); // Retrieves <input type="file" name="file">
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
        InputStream fileContent = filePart.getInputStream();

        String prefix = getServletContext().getRealPath("/") + "image";
        prefix = prefix.replace("\\build", "");
        File path = new File(prefix);
        File file = new File(path, fileName);
        Files.copy(fileContent, file.toPath(), StandardCopyOption.REPLACE_EXISTING);

        Event eventdetail = new Event(eventID, eventName, eventdesc, EventCat, StartRegDate, EndRegDate, StartDate, EndDate, MemPrice, NonMemPrice,fileName);
        try {
            utx.begin();
            em.persist(eventdetail);
            utx.commit();

            resp.sendRedirect("RetrieveEvent");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
