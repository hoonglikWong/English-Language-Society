/**
 *
 * @author Lee Meng Jian
 */
package Controller;

import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

public class signUpProcess extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String IC = req.getParameter("IC");
            String password = req.getParameter("PASSWORD");
            String name = req.getParameter("PERSONNAME");
            String gender = req.getParameter("GENDER");
            String hpNum = req.getParameter("PHONENUM");
            String email = req.getParameter("EMAIL");

            boolean matched = false;
            int count = 0;
            Date date = Calendar.getInstance().getTime();
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String today = formatter.format(date);
            Query q = em.createNamedQuery("Person.findAll");
            List<Person> PersonList = q.getResultList();

            for (int i = 0; i < PersonList.size(); i++) {
                if (PersonList.get(i).getIc().equals(IC)) {
                    matched = true;
                    count = i;
                }
            }

            if (matched) {
                if (PersonList.get(count).getStatus().equals("EXPELLED")) {
                    Person errorData = new Person(IC, name, hpNum, password, "EXPELLED", today, gender, email,"","profileimage.png");
                    req.setAttribute("signUpErrorData", errorData);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                } else if (PersonList.get(count).getStatus().equals("RESIGNED")) {
                    Person person = new Person(IC, name, hpNum, password, "PENDING", today, gender, email,"","profileimage.png");
                    utx.begin();
                    em.merge(person);
                    utx.commit();
                } else if (PersonList.get(count).getStatus().equals("PENDING")) {
                    Person errorData = new Person(IC, name, hpNum, password, "PENDING", today, gender, email,"","profileimage.png");
                    req.setAttribute("signUpErrorData", errorData);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                } else if (PersonList.get(count).getStatus().equals("NONMEMBER")) {
                    Person person = new Person(IC, name, hpNum, password, "PENDING", today, gender, email,"","profileimage.png");
                    utx.begin();
                    em.merge(person);
                    utx.commit();
                } else {
                    Person errorData = new Person(IC, name, hpNum, password, "MEMBER", today, gender, email,"","profileimage.png");
                    req.setAttribute("signUpErrorData", errorData);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                }
            } else {
                Person person = new Person(IC, name, hpNum, password, "PENDING", today, gender, email,"","profileimage.png");
                utx.begin();
                em.persist(person);
                utx.commit();
                resp.sendRedirect("mainPage.jsp");
            }

        } catch (Exception ex) {
            PrintWriter out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NewServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println(ex);
            out.println("</body>");
            out.println("</html>");
        }
    }

}
