/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.ManageSponsor;

import Model.Item;
import Model.Sponsor;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Law Kuan Hoo
 */
public class ItemAddServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String itemID = req.getParameter("itemID");
        String itemName = req.getParameter("itemName");
        
        Item itemdetail = new Item(itemID,itemName);
                        
        try {
            utx.begin();
            em.persist(itemdetail);
            utx.commit();
            resp.sendRedirect("RetrieveSponsor");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }

}
