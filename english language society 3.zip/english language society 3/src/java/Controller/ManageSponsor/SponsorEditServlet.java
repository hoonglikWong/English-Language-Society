/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.ManageSponsor;

import Model.Sponsor;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Law Kuan Hoo
 */
public class SponsorEditServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sponsorID = req.getParameter("sponsorID");
        String sponsorName = req.getParameter("sponsorName");
        String sponsorPhoneNum = req.getParameter("sponsorPhoneNum");
        String sponsorEmail = req.getParameter("sponsorEmail");
        Sponsor sponsordetail = new Sponsor(sponsorID, sponsorName, sponsorPhoneNum, sponsorEmail);
                        
        try {
            utx.begin();
            em.merge(sponsordetail);
            utx.commit();
            resp.sendRedirect("RetrieveSponsor");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
    }


}
