/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Lee Meng Jian
 */

package Controller;

import Model.Participation;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author hoonglik
 */
public class EventRegSlip extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String regNum = req.getParameter("regNum");
        String payeeic = req.getParameter("payeeic");
        Date date = Calendar.getInstance().getTime();

        Query q = em.createNamedQuery("Participation.findAll");
        List<Participation> ParticipationList = q.getResultList();

        Participation parti = new Participation();
        for (int i = 0; i < ParticipationList.size(); i++) {
            if (ParticipationList.get(i).getParticipationid().equals(regNum)) {
                parti = ParticipationList.get(i);
            }
        }

        Query q2 = em.createNamedQuery("Person.findAll");
        List<Person> PersonList = q2.getResultList();

        boolean valid = false;
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(payeeic)) {
                valid = true;
            }
        }

        String amount = "";
        if (valid) {
            amount = parti.getEventid().getMemberprice();
        } else {
            amount = parti.getEventid().getNonmemberprice();
        }

        PrintWriter out = resp.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"utf-8\">");
        out.println("<title>Event Registration Slip</title>");

        out.println("<style>");
        out.println(".invoice-box{");
        out.println("max-width:800px;");
        out.println("margin:auto;");
        out.println("padding:30px;");
        out.println("border:1px solid #eee;");
        out.println("box-shadow:0 0 10px rgba(0,0,0,.15);");
        out.println("font-size:16px;");
        out.println("line-height:24px;");
        out.println("font-family:'HelveticaNeue','Helvetica',Helvetica,Arial,sans-serif;");
        out.println("color:#555;");
        out.println("}");

        out.println(".invoice-box table{");
        out.println("width:100%;");
        out.println("line-height:inherit;");
        out.println("text-align:left;");
        out.println("}");

        out.println(".invoice-box table td{");
        out.println("padding:5px;");
        out.println("vertical-align:top;");
        out.println("}");

        out.println(".invoice-box table tr td:nth-child(2){");
        out.println("text-align:right;");
        out.println("}");

        out.println(".invoice-box table tr.top table td{");
        out.println("padding-bottom:20px;");
        out.println("}");

        out.println(".invoice-box table tr.top table td.title{");
        out.println("font-size:45px;");
        out.println("line-height:45px;");
        out.println("color:#333;");
        out.println("}");

        out.println(".invoice-box table tr.information table td{");
        out.println("padding-bottom:40px;");
        out.println("}");

        out.println(".invoice-box table tr.heading td{");
        out.println("background:#eee;");
        out.println("border-bottom:1px solid #ddd;");
        out.println("font-weight:bold;");
        out.println("}");

        out.println(".invoice-box table tr.details td{");
        out.println("padding-bottom:20px;");
        out.println("}");

        out.println(".invoice-box table tr.item td{");
        out.println("border-bottom:1px solid #eee;");
        out.println("}");

        out.println(".invoice-box table tr.item.last td{");
        out.println("border-bottom:none;");
        out.println("}");

        out.println(".invoice-box table tr.total td:nth-child(2){");
        out.println("border-top:2px solid #eee;");
        out.println("font-weight:bold;");
        out.println("}");

        out.println("@media only screen and(max-width:600px){");
        out.println(".invoice-box table tr.top table td{");
        out.println("width:100%;");
        out.println("display:block;");
        out.println("text-align:center;");
        out.println("}");

        out.println(".invoice-box table tr.information table td{");
        out.println("width:100%;");
        out.println("display:block;");
        out.println("text-align:center;");
        out.println("}");
        out.println("}");

        out.println("/**RTL**/");
        out.println(".rtl{");
        out.println("direction:rtl;");
        out.println("font-family:Tahoma,'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;");
        out.println("}");

        out.println(".rtl table{");
        out.println("text-align:right;");
        out.println("}");

        out.println(".rtltabletrtd:nth-child(2){");
        out.println("text-align:left;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");

        out.println("<body>");
        out.println("<div class=\"invoice-box\">");
        out.println("<table cellpadding=\"0\" cellspacing=\"0\">");
        out.println("<tr class=\"top\">");
        out.println("<td colspan=\"2\">");
        out.println("<table>");
        out.println("<tr>");
        out.println("<td class=\"title\">");
        out.println("<img src=\"image/ENGLISH.png\"style=\"width:100%;max-width:300px;\">");
        out.println("</td>");

        out.println("<td>");
        out.println("Registration Number#: " + regNum + "<br>");
        out.println("Created: " + date + "<br>");
        out.println("</td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"information\">");
        out.println("<td colspan=\"2\">");
        out.println("<table>");
        out.println("<tr>");
        out.println("<td>");
        out.println("English Language Society<br>");
        out.println("Kampus Utama, Jalan Genting Kelang,<br>");
        out.println("53300 Kuala Lumpur");
        out.println("</td>");

        out.println("<td>");
        out.println("<br>");
        out.println("" + parti.getIc().getPersonname() + "<br>");
        out.println("" + parti.getIc().getEmail());
        out.println("</td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"heading\">");
        out.println("<td>");
        out.println("Status");
        out.println("</td>");

        out.println("<td>");
        out.println("");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"details\">");
        out.println("<td>");
        out.println(""+parti.getStatus());
        out.println("</td>");

        out.println("<td>");
        out.println("");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"heading\">");
        out.println("<td>");
        out.println("Event Registration");
        out.println("</td>");

        out.println("<td>");
        out.println("Price");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"item\">");
        out.println("<td>");
        out.println("" + parti.getEventid().getEventname());
        out.println("</td>");

        out.println("<td>");
        out.println("" + amount);
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"item\">");
        out.println("<td>");
        out.println("");
        out.println("</td>");

        out.println("<td>");
        out.println("");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"itemlast\">");
        out.println("<td>");
        out.println("");
        out.println("</td>");

        out.println("<td>");
        out.println("");
        out.println("</td>");
        out.println("</tr>");

        out.println("<tr class=\"total\">");
        out.println("<td></td>");

        out.println("<td>");
        out.println("Total:RM " + amount);
        out.println("</td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("<button onclick=\"myFunction()\">Print</button>");
        out.println("</div>");
        out.println("<script>");
        out.println("function myFunction() {");
        out.println("window.print();");
        out.println("}");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");

    }

}
