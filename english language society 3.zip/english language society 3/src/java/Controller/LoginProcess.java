/**
 *
 * @author Wong Hoong Lik
 */

package Controller;

import Model.Event;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

public class LoginProcess extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String IC = req.getParameter("IC");
            String password = req.getParameter("password");
            Query q = em.createNamedQuery("Person.findAll");
            String rememberMe = req.getParameter("rememberMe");
            List<Person> PersonList = q.getResultList();

            Query q2 = em.createNamedQuery("Event.findAll");
            List<Event> EventList = q2.getResultList();
            
            String errorMessage = "";

            boolean valid = false;

            Person personlogin = new Person();
            for (int i = 0; i < PersonList.size(); i++) {
                if (PersonList.get(i).getIc().equals(IC)) {
                    if (PersonList.get(i).getPassword().equals(password)) {
                        valid = true;
                        personlogin = PersonList.get(i);
                    }
                }
            }

            if (valid) {
                if (personlogin.getStatus().equals("MEMBER") || personlogin.getStatus().equals("EXCO")) {

                    Cookie cName = new Cookie("uName", IC);
                    Cookie cPsw = new Cookie("uPsw", password);

                    if (rememberMe == null) {
                        cPsw.setMaxAge(0);
                        cName.setMaxAge(0);
                    } else {
                        cPsw.setMaxAge(60 * 60 * 24);
                        cName.setMaxAge(60 * 60 * 24);
                    }

                    resp.addCookie(cName);
                    resp.addCookie(cPsw);

                    HttpSession session = req.getSession();
                    session.setAttribute("personlogin", personlogin);
                    session.setAttribute("EventList", EventList);
                    resp.sendRedirect("mainPage.jsp");
                } else if (personlogin.getStatus().equals("EXPELLED")) {
                    errorMessage = "You have been expelled! Please refer EXCO members for assistance.";
                    req.setAttribute("errorLogin", errorMessage);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                } else if (personlogin.getStatus().equals("PENDING")) {
                    errorMessage = "Your application is still pending.";
                    req.setAttribute("errorLogin", errorMessage);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                }else{
                    errorMessage = "Invalid login ID or password!";
                    req.setAttribute("errorLogin", errorMessage);
                    RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                    rd.forward(req, resp);
                    
                }
            } else {
                errorMessage = "Invalid login ID or password!";
                req.setAttribute("errorLogin", errorMessage);
                RequestDispatcher rd = req.getRequestDispatcher("mainPage.jsp");
                rd.forward(req, resp);
            }

        } catch (Exception ex) {
            PrintWriter out = resp.getWriter();

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet EventRegSlip</title>");
            out.println("</head>");
            out.println("<body>");
            out.println(ex);
            out.println("</body>");
            out.println("</html>");
        }

    }

}
