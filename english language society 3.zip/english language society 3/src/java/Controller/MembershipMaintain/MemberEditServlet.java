/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.MembershipMaintain;

import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Wong Hoong Lik
 */
public class MemberEditServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String IC = req.getParameter("IC");
        String Name = req.getParameter("Name");
        String Psw = req.getParameter("Psw");
        String Email = req.getParameter("Email");
        String Status = req.getParameter("Status");
        String phoneNum = req.getParameter("phoneNum");
        String Gender = req.getParameter("Gender");
        String regDate = req.getParameter("RegDate");
        String excoPosition = req.getParameter("excoPosition");
        String Picture = req.getParameter("Picture");

        
        Person p;
        
        if(Status.equals("EXCO")){
            p = new Person(IC, Name, phoneNum, Psw, Status, regDate, Gender, Email,excoPosition,Picture);
        }else{
            p = new Person(IC, Name, phoneNum, Psw, Status, regDate, Gender, Email,"",Picture);
        }

        try {
            utx.begin();
            em.merge(p);
            utx.commit();
            resp.sendRedirect("RetrieveMemberData");
            //resp.sendRedirect("MainPage.jsp");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }
//        String Psw = req.getParameter("Psw");
    }

}
