package Controller.MembershipMaintain;

import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;
import javax.annotation.Resource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author Wong Hoong Lik
 */

public class MemberRejectServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String IC = req.getParameter("IC");
        Person person = em.find(Person.class, IC);
        person.setStatus("OUTSIDER");
        sendMail(IC);
       
        try {
            utx.begin();
            em.merge(person);
            utx.commit();
            resp.sendRedirect("RetrieveMemberData");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }

    public void sendMail(String participationid) {

        Query q = em.createNamedQuery("Person.findAll");
        List<Person> PersonList = q.getResultList();

        Person person = new Person();
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(participationid)) {
                person = PersonList.get(i);
            }
        }

        final String username = "hotlinkwong@gmail.com";
        final String password = "Lik96309630";

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("hotlinkwong@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(person.getEmail()));

            message.setSubject("Membership Application");
            message.setText("Hi," + person.getPersonname()
                    + ",\nYour Registration Has Been Rejected!");

            Transport.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }

}
