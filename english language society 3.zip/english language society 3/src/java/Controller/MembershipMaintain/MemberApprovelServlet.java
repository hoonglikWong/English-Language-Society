/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.MembershipMaintain;

import Model.Participation;
import Model.Payment;
import Model.Person;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.annotation.Resource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

/**
 *
 * @author Wong Hoong Lik
 */
public class MemberApprovelServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String IC = req.getParameter("IC");
        String excoid = req.getParameter("excoid");

        Person person = em.find(Person.class, IC);
        person.setStatus("MEMBER");

        Query q = em.createNamedQuery("Payment.findAll");
        List<Payment> PaymentList = q.getResultList();

        String currentID = PaymentList.get(PaymentList.size() - 1).getPaymentid();
        int numIndex = Integer.parseInt(currentID.substring(2));
        numIndex = numIndex + 1;
        String PaymentNewID = "PA" + numIndex;

        String payeeic = person.getIc();

        String amount = "5.00";

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String today = formatter.format(date);

        Person payeeclass = new Person(payeeic);
        Person recipientclass = new Person(excoid);
        
        sendMail(IC,payeeic,"MEMBER");

        Payment paymentdetail = new Payment(PaymentNewID, "MEMBERSHIP", amount, today, recipientclass, payeeclass);

        try {
            utx.begin();
            em.merge(person);
            em.persist(paymentdetail);
            utx.commit();
            resp.sendRedirect("RetrieveMemberData");
        } catch (Exception ex) {
            resp.sendRedirect("ErrorPage.jsp");
        }

    }
    
     public void sendMail(String IC,String payeeic,String status) {
         
        Query q2 = em.createNamedQuery("Person.findAll");
        Person persondetail = new Person();
        List<Person> PersonList = q2.getResultList();

        boolean valid = false;
        for (int i = 0; i < PersonList.size(); i++) {
            if (PersonList.get(i).getIc().equals(IC)) {
                persondetail = PersonList.get(i);
            }
        }
        Date date = Calendar.getInstance().getTime();

        String amount = "5.00";


        final String username = "hotlinkwong@gmail.com";
        final String password = "Lik96309630";

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("hotlinkwong@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(persondetail.getEmail()));
            
            message.setSubject("Membership Application");
            message.setContent("<!doctype html>\n"
                    + "<html>\n"
                    + "<head>\n"
                    + "    <meta charset=\"utf-8\">\n"
                    + "    <title>A simple, clean, and responsive HTML invoice template</title>\n"
                    + "    \n"
                    + "    <style>\n"
                    + "    .invoice-box {\n"
                    + "        max-width: 800px;\n"
                    + "        margin: auto;\n"
                    + "        padding: 30px;\n"
                    + "        border: 1px solid #eee;\n"
                    + "        box-shadow: 0 0 10px rgba(0, 0, 0, .15);\n"
                    + "        font-size: 16px;\n"
                    + "        line-height: 24px;\n"
                    + "        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;\n"
                    + "        color: #555;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table {\n"
                    + "        width: 100%;\n"
                    + "        line-height: inherit;\n"
                    + "        text-align: left;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table td {\n"
                    + "        padding: 5px;\n"
                    + "        vertical-align: top;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr td:nth-child(2) {\n"
                    + "        text-align: right;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.top table td {\n"
                    + "        padding-bottom: 20px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.top table td.title {\n"
                    + "        font-size: 45px;\n"
                    + "        line-height: 45px;\n"
                    + "        color: #333;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.information table td {\n"
                    + "        padding-bottom: 40px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.heading td {\n"
                    + "        background: #eee;\n"
                    + "        border-bottom: 1px solid #ddd;\n"
                    + "        font-weight: bold;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.details td {\n"
                    + "        padding-bottom: 20px;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.item td{\n"
                    + "        border-bottom: 1px solid #eee;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.item.last td {\n"
                    + "        border-bottom: none;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .invoice-box table tr.total td:nth-child(2) {\n"
                    + "        border-top: 2px solid #eee;\n"
                    + "        font-weight: bold;\n"
                    + "    }\n"
                    + "    \n"
                    + "    @media only screen and (max-width: 600px) {\n"
                    + "        .invoice-box table tr.top table td {\n"
                    + "            width: 100%;\n"
                    + "            display: block;\n"
                    + "            text-align: center;\n"
                    + "        }\n"
                    + "        \n"
                    + "        .invoice-box table tr.information table td {\n"
                    + "            width: 100%;\n"
                    + "            display: block;\n"
                    + "            text-align: center;\n"
                    + "        }\n"
                    + "    }\n"
                    + "    \n"
                    + "    /** RTL **/\n"
                    + "    .rtl {\n"
                    + "        direction: rtl;\n"
                    + "        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .rtl table {\n"
                    + "        text-align: right;\n"
                    + "    }\n"
                    + "    \n"
                    + "    .rtl table tr td:nth-child(2) {\n"
                    + "        text-align: left;\n"
                    + "    }\n"
                    + "    </style>\n"
                    + "</head>\n"
                    + "\n"
                    + "<body>\n"
                    + "    <div class=\"invoice-box\">\n"
                    + "        <table cellpadding=\"0\" cellspacing=\"0\">\n"
                    + "            <tr class=\"top\">\n"
                    + "                <td colspan=\"2\">\n"
                    + "                    <table>\n"
                    + "                        <tr>\n"
                    + "                            <td class=\"title\">\n"
                    + "                                <img src=\"https://i.imgur.com/PV5oSRZ.png\" style=\"max-width: 300px;width: 100%\"/>\n"
                    + "                            </td>\n"
                    + "                            \n"
                    + "                            <td>\n"
                    + "                                Membership ID#: " + persondetail.getIc() + "<br>\n"
                    + "                                Created: " + date + "<br>\n"
                    + "                            </td>\n"
                    + "                        </tr>\n"
                    + "                    </table>\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"information\">\n"
                    + "                <td colspan=\"2\">\n"
                    + "                    <table>\n"
                    + "                        <tr>\n"
                    + "                            <td>\n"
                    + "                                English Language Society<br>\n"
                    + "                                Kampus Utama, Jalan Genting Kelang,<br>\n"
                    + "                                53300 Kuala Lumpur\n"
                    + "                            </td>\n"
                    + "                            \n"
                    + "                            <td>\n"
                    + "                                <br>\n"
                    + "                               " + persondetail.getPersonname() + "<br>\n"
                    + "                               " + persondetail.getEmail() + "<br>\n"
                    + "                            </td>\n"
                    + "                        </tr>\n"
                    + "                    </table>\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"heading\">\n"
                    + "                <td>\n"
                    + "                    Status\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"details\">\n"
                    + "                <td>\n"
                    + "                    " + status + "\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"heading\">\n"
                    + "                <td>\n"
                    + "                    Membership Registration\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    Price\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item\">\n"
                    + "                <td>\n"
                    + "                    Membership Fees\n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                   " + amount + "\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item\">\n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"item last\">\n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                    \n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "            \n"
                    + "            <tr class=\"total\">\n"
                    + "                <td></td>\n"
                    + "                \n"
                    + "                <td>\n"
                    + "                   Total:RM " + amount + "\n"
                    + "                </td>\n"
                    + "            </tr>\n"
                    + "        </table>\n"
                    + "    </div>\n"
                    + "</body>\n"
                    + "</html>\n"
                    + "\n", "text/html");

            Transport.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }


}
