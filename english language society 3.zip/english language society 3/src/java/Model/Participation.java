/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "PARTICIPATION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Participation.findAll", query = "SELECT p FROM Participation p")
    , @NamedQuery(name = "Participation.findByParticipationid", query = "SELECT p FROM Participation p WHERE p.participationid = :participationid")
    , @NamedQuery(name = "Participation.findByStatus", query = "SELECT p FROM Participation p WHERE p.status = :status")})
public class Participation implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PARTICIPATIONID")
    private String participationid;
    @Size(max = 50)
    @Column(name = "STATUS")
    private String status;
    @JoinColumn(name = "EVENTID", referencedColumnName = "EVENTID")
    @ManyToOne(optional = false)
    private Event eventid;
    @JoinColumn(name = "IC", referencedColumnName = "IC")
    @ManyToOne(optional = false)
    private Person ic;

    public Participation() {
    }

    public Participation(String participationid, String status, Event eventid, Person ic) {
        this.participationid = participationid;
        this.status = status;
        this.eventid = eventid;
        this.ic = ic;
    }

    public Participation(String participationid) {
        this.participationid = participationid;
    }

    public String getParticipationid() {
        return participationid;
    }

    public void setParticipationid(String participationid) {
        this.participationid = participationid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Event getEventid() {
        return eventid;
    }

    public void setEventid(Event eventid) {
        this.eventid = eventid;
    }

    public Person getIc() {
        return ic;
    }

    public void setIc(Person ic) {
        this.ic = ic;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (participationid != null ? participationid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Participation)) {
            return false;
        }
        Participation other = (Participation) object;
        if ((this.participationid == null && other.participationid != null) || (this.participationid != null && !this.participationid.equals(other.participationid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Participation[ participationid=" + participationid + " ]";
    }
    
}
