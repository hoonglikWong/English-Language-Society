/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "SPONSORSHIP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sponsorship.findAll", query = "SELECT s FROM Sponsorship s")
    , @NamedQuery(name = "Sponsorship.findBySponsorshipid", query = "SELECT s FROM Sponsorship s WHERE s.sponsorshipid = :sponsorshipid")
    , @NamedQuery(name = "Sponsorship.findByItemquantity", query = "SELECT s FROM Sponsorship s WHERE s.itemquantity = :itemquantity")
    , @NamedQuery(name = "Sponsorship.findBySponsordate", query = "SELECT s FROM Sponsorship s WHERE s.sponsordate = :sponsordate")})
public class Sponsorship implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "SPONSORSHIPID")
    private String sponsorshipid;
    @Size(max = 50)
    @Column(name = "ITEMQUANTITY")
    private String itemquantity;
    @Size(max = 50)
    @Column(name = "SPONSORDATE")
    private String sponsordate;
    @JoinColumn(name = "EVENTID", referencedColumnName = "EVENTID")
    @ManyToOne
    private Event eventid;
    @JoinColumn(name = "ITEMID", referencedColumnName = "ITEMID")
    @ManyToOne(optional = false)
    private Item itemid;
    @JoinColumn(name = "SPONSORID", referencedColumnName = "SPONSORID")
    @ManyToOne(optional = false)
    private Sponsor sponsorid;

    public Sponsorship() {
    }

    public Sponsorship(String sponsorshipid, String itemquantity, String sponsordate, Event eventid, Item itemid, Sponsor sponsorid) {
        this.sponsorshipid = sponsorshipid;
        this.itemquantity = itemquantity;
        this.sponsordate = sponsordate;
        this.eventid = eventid;
        this.itemid = itemid;
        this.sponsorid = sponsorid;
    }

    public Sponsorship(String sponsorshipid) {
        this.sponsorshipid = sponsorshipid;
    }

    public String getSponsorshipid() {
        return sponsorshipid;
    }

    public void setSponsorshipid(String sponsorshipid) {
        this.sponsorshipid = sponsorshipid;
    }

    public String getItemquantity() {
        return itemquantity;
    }

    public void setItemquantity(String itemquantity) {
        this.itemquantity = itemquantity;
    }

    public String getSponsordate() {
        return sponsordate;
    }

    public void setSponsordate(String sponsordate) {
        this.sponsordate = sponsordate;
    }

    public Event getEventid() {
        return eventid;
    }

    public void setEventid(Event eventid) {
        this.eventid = eventid;
    }

    public Item getItemid() {
        return itemid;
    }

    public void setItemid(Item itemid) {
        this.itemid = itemid;
    }

    public Sponsor getSponsorid() {
        return sponsorid;
    }

    public void setSponsorid(Sponsor sponsorid) {
        this.sponsorid = sponsorid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sponsorshipid != null ? sponsorshipid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sponsorship)) {
            return false;
        }
        Sponsorship other = (Sponsorship) object;
        if ((this.sponsorshipid == null && other.sponsorshipid != null) || (this.sponsorshipid != null && !this.sponsorshipid.equals(other.sponsorshipid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Sponsorship[ sponsorshipid=" + sponsorshipid + " ]";
    }
    
}
