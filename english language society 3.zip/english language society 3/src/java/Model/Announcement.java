/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "ANNOUNCEMENT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Announcement.findAll", query = "SELECT a FROM Announcement a")
    , @NamedQuery(name = "Announcement.findByAnnid", query = "SELECT a FROM Announcement a WHERE a.annid = :annid")
    , @NamedQuery(name = "Announcement.findByAnntitle", query = "SELECT a FROM Announcement a WHERE a.anntitle = :anntitle")
    , @NamedQuery(name = "Announcement.findByAnndetail", query = "SELECT a FROM Announcement a WHERE a.anndetail = :anndetail")
    , @NamedQuery(name = "Announcement.findByAnndate", query = "SELECT a FROM Announcement a WHERE a.anndate = :anndate")})
public class Announcement implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ANNID")
    private String annid;
    @Size(max = 50)
    @Column(name = "ANNTITLE")
    private String anntitle;
    @Size(max = 255)
    @Column(name = "ANNDETAIL")
    private String anndetail;
    @Size(max = 50)
    @Column(name = "ANNDATE")
    private String anndate;

    public Announcement() {
    }

    public Announcement(String annid) {
        this.annid = annid;
    }

    public String getAnnid() {
        return annid;
    }

    public void setAnnid(String annid) {
        this.annid = annid;
    }

    public String getAnntitle() {
        return anntitle;
    }

    public void setAnntitle(String anntitle) {
        this.anntitle = anntitle;
    }

    public String getAnndetail() {
        return anndetail;
    }

    public void setAnndetail(String anndetail) {
        this.anndetail = anndetail;
    }

    public String getAnndate() {
        return anndate;
    }

    public void setAnndate(String anndate) {
        this.anndate = anndate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (annid != null ? annid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Announcement)) {
            return false;
        }
        Announcement other = (Announcement) object;
        if ((this.annid == null && other.annid != null) || (this.annid != null && !this.annid.equals(other.annid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Announcement[ annid=" + annid + " ]";
    }
    
}
