/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "SURVEY")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Survey.findAll", query = "SELECT s FROM Survey s")
    , @NamedQuery(name = "Survey.findByStudname", query = "SELECT s FROM Survey s WHERE s.studname = :studname")
    , @NamedQuery(name = "Survey.findByStudid", query = "SELECT s FROM Survey s WHERE s.studid = :studid")
    , @NamedQuery(name = "Survey.findByProgcode", query = "SELECT s FROM Survey s WHERE s.progcode = :progcode")
    , @NamedQuery(name = "Survey.findByGender", query = "SELECT s FROM Survey s WHERE s.gender = :gender")
    , @NamedQuery(name = "Survey.findByExco", query = "SELECT s FROM Survey s WHERE s.exco = :exco")
    , @NamedQuery(name = "Survey.findByEvent", query = "SELECT s FROM Survey s WHERE s.event = :event")
    , @NamedQuery(name = "Survey.findByLearn", query = "SELECT s FROM Survey s WHERE s.learn = :learn")
    , @NamedQuery(name = "Survey.findByOverall", query = "SELECT s FROM Survey s WHERE s.overall = :overall")
    , @NamedQuery(name = "Survey.findByUi", query = "SELECT s FROM Survey s WHERE s.ui = :ui")
    , @NamedQuery(name = "Survey.findByFrequent", query = "SELECT s FROM Survey s WHERE s.frequent = :frequent")
    , @NamedQuery(name = "Survey.findBySystem", query = "SELECT s FROM Survey s WHERE s.system = :system")
    , @NamedQuery(name = "Survey.findByComment1", query = "SELECT s FROM Survey s WHERE s.comment1 = :comment1")
    , @NamedQuery(name = "Survey.findByComment2", query = "SELECT s FROM Survey s WHERE s.comment2 = :comment2")
    , @NamedQuery(name = "Survey.findByOpinion1", query = "SELECT s FROM Survey s WHERE s.opinion1 = :opinion1")
    , @NamedQuery(name = "Survey.findByOpinion2", query = "SELECT s FROM Survey s WHERE s.opinion2 = :opinion2")})
public class Survey implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 50)
    @Column(name = "STUDNAME")
    private String studname;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 12)
    @Column(name = "STUDID")
    private String studid;
    @Size(max = 3)
    @Column(name = "PROGCODE")
    private String progcode;
    @Size(max = 6)
    @Column(name = "GENDER")
    private String gender;
    @Column(name = "EXCO")
    private Integer exco;
    @Column(name = "EVENT")
    private Integer event;
    @Column(name = "LEARN")
    private Integer learn;
    @Column(name = "OVERALL")
    private Integer overall;
    @Column(name = "UI")
    private Integer ui;
    @Column(name = "FREQUENT")
    private Integer frequent;
    @Column(name = "SYSTEM")
    private Integer system;
    @Size(max = 10)
    @Column(name = "COMMENT1")
    private String comment1;
    @Size(max = 10)
    @Column(name = "COMMENT2")
    private String comment2;
    @Size(max = 200)
    @Column(name = "OPINION1")
    private String opinion1;
    @Size(max = 200)
    @Column(name = "OPINION2")
    private String opinion2;

    public Survey(String studname, String studid, String progcode, String gender, Integer exco, Integer event, Integer learn, Integer overall, Integer ui, Integer frequent, Integer system, String comment1, String comment2, String opinion1, String opinion2) {
        this.studname = studname;
        this.studid = studid;
        this.progcode = progcode;
        this.gender = gender;
        this.exco = exco;
        this.event = event;
        this.learn = learn;
        this.overall = overall;
        this.ui = ui;
        this.frequent = frequent;
        this.system = system;
        this.comment1 = comment1;
        this.comment2 = comment2;
        this.opinion1 = opinion1;
        this.opinion2 = opinion2;
    }

    public Survey() {
    }

    public Survey(String studid) {
        this.studid = studid;
    }

    public String getStudname() {
        return studname;
    }

    public void setStudname(String studname) {
        this.studname = studname;
    }

    public String getStudid() {
        return studid;
    }

    public void setStudid(String studid) {
        this.studid = studid;
    }

    public String getProgcode() {
        return progcode;
    }

    public void setProgcode(String progcode) {
        this.progcode = progcode;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getExco() {
        return exco;
    }

    public void setExco(Integer exco) {
        this.exco = exco;
    }

    public Integer getEvent() {
        return event;
    }

    public void setEvent(Integer event) {
        this.event = event;
    }

    public Integer getLearn() {
        return learn;
    }

    public void setLearn(Integer learn) {
        this.learn = learn;
    }

    public Integer getOverall() {
        return overall;
    }

    public void setOverall(Integer overall) {
        this.overall = overall;
    }

    public Integer getUi() {
        return ui;
    }

    public void setUi(Integer ui) {
        this.ui = ui;
    }

    public Integer getFrequent() {
        return frequent;
    }

    public void setFrequent(Integer frequent) {
        this.frequent = frequent;
    }

    public Integer getSystem() {
        return system;
    }

    public void setSystem(Integer system) {
        this.system = system;
    }

    public String getComment1() {
        return comment1;
    }

    public void setComment1(String comment1) {
        this.comment1 = comment1;
    }

    public String getComment2() {
        return comment2;
    }

    public void setComment2(String comment2) {
        this.comment2 = comment2;
    }

    public String getOpinion1() {
        return opinion1;
    }

    public void setOpinion1(String opinion1) {
        this.opinion1 = opinion1;
    }

    public String getOpinion2() {
        return opinion2;
    }

    public void setOpinion2(String opinion2) {
        this.opinion2 = opinion2;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (studid != null ? studid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Survey)) {
            return false;
        }
        Survey other = (Survey) object;
        if ((this.studid == null && other.studid != null) || (this.studid != null && !this.studid.equals(other.studid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Survey[ studid=" + studid + " ]";
    }
    
}
