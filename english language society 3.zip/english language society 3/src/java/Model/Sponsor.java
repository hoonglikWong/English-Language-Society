/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "SPONSOR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sponsor.findAll", query = "SELECT s FROM Sponsor s")
    , @NamedQuery(name = "Sponsor.findBySponsorid", query = "SELECT s FROM Sponsor s WHERE s.sponsorid = :sponsorid")
    , @NamedQuery(name = "Sponsor.findBySponsorname", query = "SELECT s FROM Sponsor s WHERE s.sponsorname = :sponsorname")
    , @NamedQuery(name = "Sponsor.findBySponsorphonenum", query = "SELECT s FROM Sponsor s WHERE s.sponsorphonenum = :sponsorphonenum")
    , @NamedQuery(name = "Sponsor.findBySponsoremail", query = "SELECT s FROM Sponsor s WHERE s.sponsoremail = :sponsoremail")})
public class Sponsor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "SPONSORID")
    private String sponsorid;
    @Size(max = 50)
    @Column(name = "SPONSORNAME")
    private String sponsorname;
    @Size(max = 50)
    @Column(name = "SPONSORPHONENUM")
    private String sponsorphonenum;
    @Size(max = 50)
    @Column(name = "SPONSOREMAIL")
    private String sponsoremail;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sponsorid")
    private List<Sponsorship> sponsorshipList;

    public Sponsor() {
    }

    public Sponsor(String sponsorid, String sponsorname, String sponsorphonenum, String sponsoremail) {
        this.sponsorid = sponsorid;
        this.sponsorname = sponsorname;
        this.sponsorphonenum = sponsorphonenum;
        this.sponsoremail = sponsoremail;
    }

    public Sponsor(String sponsorid) {
        this.sponsorid = sponsorid;
    }

    public String getSponsorid() {
        return sponsorid;
    }

    public void setSponsorid(String sponsorid) {
        this.sponsorid = sponsorid;
    }

    public String getSponsorname() {
        return sponsorname;
    }

    public void setSponsorname(String sponsorname) {
        this.sponsorname = sponsorname;
    }

    public String getSponsorphonenum() {
        return sponsorphonenum;
    }

    public void setSponsorphonenum(String sponsorphonenum) {
        this.sponsorphonenum = sponsorphonenum;
    }

    public String getSponsoremail() {
        return sponsoremail;
    }

    public void setSponsoremail(String sponsoremail) {
        this.sponsoremail = sponsoremail;
    }

    @XmlTransient
    public List<Sponsorship> getSponsorshipList() {
        return sponsorshipList;
    }

    public void setSponsorshipList(List<Sponsorship> sponsorshipList) {
        this.sponsorshipList = sponsorshipList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sponsorid != null ? sponsorid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sponsor)) {
            return false;
        }
        Sponsor other = (Sponsor) object;
        if ((this.sponsorid == null && other.sponsorid != null) || (this.sponsorid != null && !this.sponsorid.equals(other.sponsorid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Sponsor[ sponsorid=" + sponsorid + " ]";
    }
    
}
