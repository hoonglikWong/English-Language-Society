/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "EVENT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Event.findAll", query = "SELECT e FROM Event e")
    , @NamedQuery(name = "Event.findByEventid", query = "SELECT e FROM Event e WHERE e.eventid = :eventid")
    , @NamedQuery(name = "Event.findByEventname", query = "SELECT e FROM Event e WHERE e.eventname = :eventname")
    , @NamedQuery(name = "Event.findByEventdesc", query = "SELECT e FROM Event e WHERE e.eventdesc = :eventdesc")
    , @NamedQuery(name = "Event.findByEventcat", query = "SELECT e FROM Event e WHERE e.eventcat = :eventcat")
    , @NamedQuery(name = "Event.findByStartregdate", query = "SELECT e FROM Event e WHERE e.startregdate = :startregdate")
    , @NamedQuery(name = "Event.findByEndregdate", query = "SELECT e FROM Event e WHERE e.endregdate = :endregdate")
    , @NamedQuery(name = "Event.findByStartdate", query = "SELECT e FROM Event e WHERE e.startdate = :startdate")
    , @NamedQuery(name = "Event.findByEnddate", query = "SELECT e FROM Event e WHERE e.enddate = :enddate")
    , @NamedQuery(name = "Event.findByMemberprice", query = "SELECT e FROM Event e WHERE e.memberprice = :memberprice")
    , @NamedQuery(name = "Event.findByNonmemberprice", query = "SELECT e FROM Event e WHERE e.nonmemberprice = :nonmemberprice")
    , @NamedQuery(name = "Event.findByPicture", query = "SELECT e FROM Event e WHERE e.picture = :picture")})
public class Event implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "EVENTID")
    private String eventid;
    @Size(max = 50)
    @Column(name = "EVENTNAME")
    private String eventname;
    @Size(max = 255)
    @Column(name = "EVENTDESC")
    private String eventdesc;
    @Size(max = 50)
    @Column(name = "EVENTCAT")
    private String eventcat;
    @Size(max = 50)
    @Column(name = "STARTREGDATE")
    private String startregdate;
    @Size(max = 50)
    @Column(name = "ENDREGDATE")
    private String endregdate;
    @Size(max = 50)
    @Column(name = "STARTDATE")
    private String startdate;
    @Size(max = 50)
    @Column(name = "ENDDATE")
    private String enddate;
    @Size(max = 50)
    @Column(name = "MEMBERPRICE")
    private String memberprice;
    @Size(max = 50)
    @Column(name = "NONMEMBERPRICE")
    private String nonmemberprice;
    @Size(max = 50)
    @Column(name = "PICTURE")
    private String picture;
    @OneToMany(mappedBy = "eventid")
    private List<Sponsorship> sponsorshipList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "eventid")
    private List<Participation> participationList;

    public Event() {
    }

    public Event(String eventid, String eventname, String eventdesc, String eventcat, String startregdate, String endregdate, String startdate, String enddate, String memberprice, String nonmemberprice, String picture) {
        this.eventid = eventid;
        this.eventname = eventname;
        this.eventdesc = eventdesc;
        this.eventcat = eventcat;
        this.startregdate = startregdate;
        this.endregdate = endregdate;
        this.startdate = startdate;
        this.enddate = enddate;
        this.memberprice = memberprice;
        this.nonmemberprice = nonmemberprice;
        this.picture = picture;
    }

    public Event(String eventid) {
        this.eventid = eventid;
    }

    public String getEventid() {
        return eventid;
    }

    public void setEventid(String eventid) {
        this.eventid = eventid;
    }

    public String getEventname() {
        return eventname;
    }

    public void setEventname(String eventname) {
        this.eventname = eventname;
    }

    public String getEventdesc() {
        return eventdesc;
    }

    public void setEventdesc(String eventdesc) {
        this.eventdesc = eventdesc;
    }

    public String getEventcat() {
        return eventcat;
    }

    public void setEventcat(String eventcat) {
        this.eventcat = eventcat;
    }

    public String getStartregdate() {
        return startregdate;
    }

    public void setStartregdate(String startregdate) {
        this.startregdate = startregdate;
    }

    public String getEndregdate() {
        return endregdate;
    }

    public void setEndregdate(String endregdate) {
        this.endregdate = endregdate;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getMemberprice() {
        return memberprice;
    }

    public void setMemberprice(String memberprice) {
        this.memberprice = memberprice;
    }

    public String getNonmemberprice() {
        return nonmemberprice;
    }

    public void setNonmemberprice(String nonmemberprice) {
        this.nonmemberprice = nonmemberprice;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @XmlTransient
    public List<Sponsorship> getSponsorshipList() {
        return sponsorshipList;
    }

    public void setSponsorshipList(List<Sponsorship> sponsorshipList) {
        this.sponsorshipList = sponsorshipList;
    }

    @XmlTransient
    public List<Participation> getParticipationList() {
        return participationList;
    }

    public void setParticipationList(List<Participation> participationList) {
        this.participationList = participationList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (eventid != null ? eventid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Event)) {
            return false;
        }
        Event other = (Event) object;
        if ((this.eventid == null && other.eventid != null) || (this.eventid != null && !this.eventid.equals(other.eventid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Event[ eventid=" + eventid + " ]";
    }
    
}
