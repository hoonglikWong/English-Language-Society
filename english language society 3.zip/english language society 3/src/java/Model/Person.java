/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "PERSON")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Person.findAll", query = "SELECT p FROM Person p")
    , @NamedQuery(name = "Person.findByIc", query = "SELECT p FROM Person p WHERE p.ic = :ic")
    , @NamedQuery(name = "Person.findByPersonname", query = "SELECT p FROM Person p WHERE p.personname = :personname")
    , @NamedQuery(name = "Person.findByPhonenum", query = "SELECT p FROM Person p WHERE p.phonenum = :phonenum")
    , @NamedQuery(name = "Person.findByPassword", query = "SELECT p FROM Person p WHERE p.password = :password")
    , @NamedQuery(name = "Person.findByStatus", query = "SELECT p FROM Person p WHERE p.status = :status")
    , @NamedQuery(name = "Person.findByRegdate", query = "SELECT p FROM Person p WHERE p.regdate = :regdate")
    , @NamedQuery(name = "Person.findByGender", query = "SELECT p FROM Person p WHERE p.gender = :gender")
    , @NamedQuery(name = "Person.findByEmail", query = "SELECT p FROM Person p WHERE p.email = :email")
    , @NamedQuery(name = "Person.findByExcoposition", query = "SELECT p FROM Person p WHERE p.excoposition = :excoposition")
    , @NamedQuery(name = "Person.findByPicture", query = "SELECT p FROM Person p WHERE p.picture = :picture")})
public class Person implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 12)
    @Column(name = "IC")
    private String ic;
    @Size(max = 50)
    @Column(name = "PERSONNAME")
    private String personname;
    @Size(max = 50)
    @Column(name = "PHONENUM")
    private String phonenum;
    @Size(max = 50)
    @Column(name = "PASSWORD")
    private String password;
    @Size(max = 20)
    @Column(name = "STATUS")
    private String status;
    @Size(max = 50)
    @Column(name = "REGDATE")
    private String regdate;
    @Size(max = 50)
    @Column(name = "GENDER")
    private String gender;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 50)
    @Column(name = "EXCOPOSITION")
    private String excoposition;
    @Size(max = 50)
    @Column(name = "PICTURE")
    private String picture;
    @OneToMany(mappedBy = "recipient")
    private List<Payment> paymentList;
    @OneToMany(mappedBy = "payee")
    private List<Payment> paymentList1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ic")
    private List<Participation> participationList;

    public Person() {
    }

    public Person(String ic, String personname, String phonenum, String password, String status, String regdate, String gender, String email, String excoposition, String picture) {
        this.ic = ic;
        this.personname = personname;
        this.phonenum = phonenum;
        this.password = password;
        this.status = status;
        this.regdate = regdate;
        this.gender = gender;
        this.email = email;
        this.excoposition = excoposition;
        this.picture = picture;
    }

    public Person(String ic) {
        this.ic = ic;
    }

    public String getIc() {
        return ic;
    }

    public void setIc(String ic) {
        this.ic = ic;
    }

    public String getPersonname() {
        return personname;
    }

    public void setPersonname(String personname) {
        this.personname = personname;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRegdate() {
        return regdate;
    }

    public void setRegdate(String regdate) {
        this.regdate = regdate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getExcoposition() {
        return excoposition;
    }

    public void setExcoposition(String excoposition) {
        this.excoposition = excoposition;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @XmlTransient
    public List<Payment> getPaymentList() {
        return paymentList;
    }

    public void setPaymentList(List<Payment> paymentList) {
        this.paymentList = paymentList;
    }

    @XmlTransient
    public List<Payment> getPaymentList1() {
        return paymentList1;
    }

    public void setPaymentList1(List<Payment> paymentList1) {
        this.paymentList1 = paymentList1;
    }

    @XmlTransient
    public List<Participation> getParticipationList() {
        return participationList;
    }

    public void setParticipationList(List<Participation> participationList) {
        this.participationList = participationList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ic != null ? ic.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Person)) {
            return false;
        }
        Person other = (Person) object;
        if ((this.ic == null && other.ic != null) || (this.ic != null && !this.ic.equals(other.ic))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Person[ ic=" + ic + " ]";
    }
    
}
