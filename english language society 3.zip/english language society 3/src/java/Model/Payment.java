/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hoonglik
 */
@Entity
@Table(name = "PAYMENT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Payment.findAll", query = "SELECT p FROM Payment p")
    , @NamedQuery(name = "Payment.findByPaymentid", query = "SELECT p FROM Payment p WHERE p.paymentid = :paymentid")
    , @NamedQuery(name = "Payment.findByPaymentpurpose", query = "SELECT p FROM Payment p WHERE p.paymentpurpose = :paymentpurpose")
    , @NamedQuery(name = "Payment.findByAmount", query = "SELECT p FROM Payment p WHERE p.amount = :amount")
    , @NamedQuery(name = "Payment.findByPaymentdate", query = "SELECT p FROM Payment p WHERE p.paymentdate = :paymentdate")})
public class Payment implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PAYMENTID")
    private String paymentid;
    @Size(max = 50)
    @Column(name = "PAYMENTPURPOSE")
    private String paymentpurpose;
    @Size(max = 50)
    @Column(name = "AMOUNT")
    private String amount;
    @Size(max = 50)
    @Column(name = "PAYMENTDATE")
    private String paymentdate;
    @JoinColumn(name = "RECIPIENT", referencedColumnName = "IC")
    @ManyToOne
    private Person recipient;
    @JoinColumn(name = "PAYEE", referencedColumnName = "IC")
    @ManyToOne
    private Person payee;

    public Payment() {
    }

    public Payment(String paymentid, String paymentpurpose, String amount, String paymentdate, Person recipient, Person payee) {
        this.paymentid = paymentid;
        this.paymentpurpose = paymentpurpose;
        this.amount = amount;
        this.paymentdate = paymentdate;
        this.recipient = recipient;
        this.payee = payee;
    }

    public Payment(String paymentid) {
        this.paymentid = paymentid;
    }

    public String getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(String paymentid) {
        this.paymentid = paymentid;
    }

    public String getPaymentpurpose() {
        return paymentpurpose;
    }

    public void setPaymentpurpose(String paymentpurpose) {
        this.paymentpurpose = paymentpurpose;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(String paymentdate) {
        this.paymentdate = paymentdate;
    }

    public Person getRecipient() {
        return recipient;
    }

    public void setRecipient(Person recipient) {
        this.recipient = recipient;
    }

    public Person getPayee() {
        return payee;
    }

    public void setPayee(Person payee) {
        this.payee = payee;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paymentid != null ? paymentid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Payment)) {
            return false;
        }
        Payment other = (Payment) object;
        if ((this.paymentid == null && other.paymentid != null) || (this.paymentid != null && !this.paymentid.equals(other.paymentid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Payment[ paymentid=" + paymentid + " ]";
    }
    
}
