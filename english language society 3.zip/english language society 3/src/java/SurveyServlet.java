/**
 *
 * @author Wong Guo Zheng
 */
import Model.Survey;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

public class SurveyServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("studName");
        String id = req.getParameter("studId");
        String code = req.getParameter("progCode");
        String gender = req.getParameter("studGender");
        String exco = req.getParameter("exco");
        String event = req.getParameter("event");
        String overall = req.getParameter("overall");
        String learn = req.getParameter("learn");

        String ui = req.getParameter("ui");
        String frequent = req.getParameter("frequent");
        String systemWord = req.getParameter("systemWord");
        

        int Overall = Integer.parseInt(overall);
        int Exco = Integer.parseInt(exco);
        int Event = Integer.parseInt(event);
        int Learn = Integer.parseInt(learn);
        int UI = Integer.parseInt(ui);
        int Frequent = Integer.parseInt(frequent);
        int SystemWord = Integer.parseInt(systemWord);
        String Comment1 = defineComment1(Exco, Event, Learn, Overall);
        String Comment2 = defineComment2(UI, Frequent, SystemWord);

        String Opinion1 = req.getParameter("opinion1");
        String Opinion2 = req.getParameter("opinion2");

        
        Survey studentSurveyDetail = new Survey(name ,id, code, gender,
                Exco, Event, Learn, Overall, UI,
                Frequent, SystemWord, Comment1,Comment2, Opinion1, Opinion2);
        try {
            
            utx.begin();
            em.persist(studentSurveyDetail);
            utx.commit();
            
            HttpSession session = req.getSession();
            session.setAttribute("student", studentSurveyDetail);

            resp.sendRedirect("SurveyForm.jsp");

        } catch (Exception ex) {
            PrintWriter out = resp.getWriter();
            out.println(ex.getMessage());

        }
    }

    public static String defineComment1(int Exco, int Event, int Learn, int Overall) {
        int Sum = 0;
        String comment1;
        Sum += Overall + Exco + Event + Learn;
        if (Sum < 12) {
            comment1 = "Unsatisfied";
        } else if (Sum < 16) {
            comment1 = "Acceptable";
        } else {
            comment1 = "Satisfied";
        }
        return comment1;
    }

    public static String defineComment2(int UI, int Frequent, int System) {
        int Sum = 0;
        String comment2;
        Sum += UI + Frequent + System;
        if (Sum < 9) {
            comment2 = "Unsatisfied";
        } else if (Sum < 12) {
            comment2 = "Acceptable";
        } else {
            comment2 = "Satisfied";
        }
        return comment2;
    }

}
