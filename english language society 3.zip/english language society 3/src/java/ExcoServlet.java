/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Wong Guo Zheng
 */





import Model.Survey;
import java.io.IOException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;

public class ExcoServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;

    @Resource
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Query q = em.createNamedQuery("Survey.findAll");
        List<Survey> surveyList = q.getResultList();
        HttpSession session = req.getSession();
        session.setAttribute("surveyList", surveyList);
        resp.sendRedirect("excoSurvey.jsp");
    }
}
