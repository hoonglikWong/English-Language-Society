/**
 *
 * @author Wong Guo Zheng
 */

import Model.Person;
import Model.Survey;
import java.io.IOException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class surveyValidate extends HttpServlet {
  @PersistenceContext
    EntityManager em;
    @Resource
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Query q = em.createNamedQuery("Survey.findAll");
        boolean valid = true;
        Person personDetail = (Person) req.getSession().getAttribute("personlogin");    
        List<Survey> surveyList = q.getResultList();
            HttpSession session = req.getSession();  
            session.setAttribute("surveyList", surveyList);
           for(int i =0; i<surveyList.size();i++){
           if(personDetail.getIc().equals(surveyList.get(i).getStudid())){
               valid=false;
            }
           }
           if(valid==false){
           resp.sendRedirect("mainPage.jsp");
           }else {
           resp.sendRedirect("demo.jsp");
           }
    }

}
